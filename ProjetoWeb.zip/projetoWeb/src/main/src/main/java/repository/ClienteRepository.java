package repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import model.Cliente;

public class ClienteRepository {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("clientes");
	EntityManager manager = factory.createEntityManager();
	
	public void salvar(Cliente cliente) {
		
		manager.getTransaction().begin();
		manager.persist(cliente);
		manager.getTransaction().commit();
		manager.close();
	}
	public void deletar(Cliente cliente) {
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("clientes");
		//EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		manager.remove(cliente);
		manager.getTransaction().commit();
		manager.close();
	}
	public void editar(Cliente cliente) {
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("clientes");
		//EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		manager.merge(cliente);
		manager.getTransaction().commit();
		manager.close();
	}
	public List<Cliente> findAll() {
		//EntityManagerFactory factory = Persistence.createEntityManagerFactory("clientes");
		//EntityManager manager = factory.createEntityManager();
		manager.getTransaction().begin();
		List<Cliente> clientes = manager.createQuery("SELECT u FROM Cliente u").getResultList();
		manager.close();
		return clientes;
	}
	

}

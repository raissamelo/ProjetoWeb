package controler;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Cliente;
import service.ClienteService;

@WebServlet("/cadCliente")

public class ClienteControler extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private Cliente cliente;
	private ClienteService service;

	public ClienteControler() {

		this.cliente = new Cliente();
		this.service = new ClienteService();

	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		
		
		this.cliente.setNome(nome);
		this.cliente.setEmail(email);
		
		this.service.salvar(cliente);
		
	}
}

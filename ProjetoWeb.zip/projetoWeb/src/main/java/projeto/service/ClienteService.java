package projeto.service;

import java.util.List;

import projeto.model.Cliente;
import projeto.repository.ClienteRepository;

public class ClienteService {

		
		public ClienteRepository repository;
			
			public ClienteService() {
				this.repository = new ClienteRepository();
			}
			
			public void salvar(Cliente cliente) {
				this.repository.salvar(cliente);
			}
			
			public void deletar(Cliente cliente) {
				this.repository.deletar(cliente);
			}
			
			public void editar(Cliente cliente) {
				this.repository.editar(cliente);
			}
			
			public List<Cliente> findAll() {
				return this.repository.findAll();
			}
			
}


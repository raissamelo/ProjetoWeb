package projeto.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import projeto.model.Cliente;
import projeto.service.ClienteService;

@WebServlet("/salvaCliente")
public class CadastrarClienteController extends HttpServlet {
	
		private static final long serialVersionUID = 1L;
		
		private Cliente cliente;
		private ClienteService service;
		   
	    public void CadastroContatoController() {
	    	this.service = new ClienteService();
	    	this.cliente = new Cliente();
	    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String nome = request.getParameter("nome");
		String email = request.getParameter("email");
		String telefone = request.getParameter("telefone");
		
		this.cliente.setNome(nome);
		this.cliente.setEmail(email);
		this.cliente.setTelefone(telefone);
		
		this.service.salvar(cliente);
		}
}
